#' @param split1,split2 Logical vectors listing leaves in a consistent order,
#' identifying each leaf as a member of the ingroup (`TRUE`) or outgroup 
#' (`FALSE`) of the split in question.
