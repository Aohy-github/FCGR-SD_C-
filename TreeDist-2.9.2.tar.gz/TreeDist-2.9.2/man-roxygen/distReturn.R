#' @return <%= returns %> an array of numerics providing the
#' distances between each  pair of trees in `tree1` and `tree2`,
#' or `splits1` and `splits2`.
#' 
