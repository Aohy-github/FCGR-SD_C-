#' @param tree1,tree2 Single trees of class `phylo` to undergo comparison.
