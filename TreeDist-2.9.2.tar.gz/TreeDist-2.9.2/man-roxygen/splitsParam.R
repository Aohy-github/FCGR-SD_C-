#' @param splits A vector of integers listing the number of leaves in each of a
#' series of partitions.  For example, \kbd{c(3, 5)} states that a set of eight
#' leaves is split into a group of three and a group of five.
