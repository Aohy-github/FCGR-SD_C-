library("testthat", warn.conflicts = FALSE)
library("TreeDist")

test_check("TreeDist")
