devtools::load_all()
devtools::run_examples()
devtools::build_vignettes()
devtools::test()